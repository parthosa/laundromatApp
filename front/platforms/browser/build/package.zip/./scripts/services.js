'use strict';

angular.module('latchApp')
    .service('chatData', function() {
      this.chatId = "133";
      this.chatUrl = "BugSAP";
      this.chatPic = 'https://avatars3.githubusercontent.com/u/10223953';
    });

;
